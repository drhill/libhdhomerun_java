package com.android.monsterbutt.tv;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.android.monsterbutt.tv.AndroidTVService.AndroidServiceChannelStatusCallBack;
import com.android.monsterbutt.tv.AndroidTVService.AndroidServiceScanCallBack;
import com.android.monsterbutt.tv.AndroidTVService.AndroidTVProjectBinder;
import com.android.monsterbutt.tvstuff.Channel;
import com.android.monsterbutt.tvstuff.DeviceMgr.deviceStatus;
import com.android.monsterbutt.tvstuff.DeviceMgr_ChannelList.DevChannel;
import com.android.monsterbutt.tvstuff.TuningDevice.ChannelStatus;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.GestureDetector.OnGestureListener;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.TableLayout.LayoutParams;


public class AndroidTVProjectActivity extends Activity implements OnGestureListener {
    
    private static final String	mChannelActionLock = "ChannelActionLock";
    private boolean			mChannelActionLocked = false;
    
    private deviceStatus[] 			mDevList = null;
    private AndroidTVProjectActivity mMe = null;
    private AndroidTVProjectBinder mService = null;
    
    private GestureDetector gestureScanner = null;
    private TableLayout mGuide = null;
    private boolean mIsBound = false;
    private TextView mCurrentChannel = null;
    
	private VideoView			mVideoView = null;
    private SurfaceView mSurface;

	
	private static final int HIDE_TIMEOUT = 5000;
	private static final int CHANNELCHECK_TIMEOUT = 4000;
    private ProgressDialog mPD = null;

    private ActionBar mActionBar = null;
    
    private LinearLayout mInfoBar = null;
    private ScrollView mGuideBar = null;
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  Because we have bound to a explicit
            // service that we know is running in our own process, we can
            // cast its IBinder to a concrete class and directly access it.
        	 mService = (AndroidTVProjectBinder) service;
             mIsBound = true;
             mPD.setMessage("Scanning Devices");
             new DeviceScanInit().execute(new Void[0]);
        }

        public void onServiceDisconnected(ComponentName className) {
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            // Because it is running in our same process, we should never
            // see this happen.
            mService = null;
            mIsBound = false;
        }
    };
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mVideoView = (VideoView) this.findViewById(R.id.videoView);
        
        mActionBar = getActionBar();
        mInfoBar = (LinearLayout) this.findViewById(R.id.infoBarLayout);
        mInfoBar.setVisibility(View.INVISIBLE);        
                       
        mCurrentChannel = (TextView) this.findViewById(R.id.currentChannel);				
		mCurrentChannel.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		clearCurrentChannel();
        	}
        });
		mGuideBar = (ScrollView) this.findViewById(R.id.guideScroll);
		mGuide = (TableLayout) this.findViewById(R.id.guideLayout);		
		
        gestureScanner = new GestureDetector(this);
        
    }


    void doBindService() {
        // Establish a connection with the service.  We use an explicit
        // class name because we want a specific service implementation that
        // we know will be running in our own process (and thus won't be
        // supporting component replacement by other applications).
    	if(mIsBound == false) 
    		bindService(new Intent(this, AndroidTVService.class), mConnection, Context.BIND_AUTO_CREATE);
    }

    void doUnbindService() {
        if (mIsBound) {
            // Detach our existing connection.
            unbindService(mConnection);
            mIsBound = false;
        }
    }

    
    @Override
    public void onStart() {
    	super.onStart();
    	
        // Show the ProgressDialog on this thread
    	mMe = this;
        mPD = ProgressDialog.show(mMe, "Initializing", "Loading Service", true, false);
    	doBindService();    	
    }
    
    @Override
    public void onStop() {
    	super.onStop();
    	doUnbindService();
    }    
    
    private static final int IS_READY_TIMEOUT = 10000;
    
    private class DeviceScanInit extends AsyncTask<Void, Void, Boolean> {
    	
    	 protected Boolean doInBackground(Void... params) {
	         boolean ret = false;
	         
	        // long timeout = System.currentTimeMillis() + IS_READY_TIMEOUT;
	         
	         while(true) {//timeout > System.currentTimeMillis()) {
	        	 if(mService.isReady()) {
	        		 ret = true;
	        		 break;
	        	 }
	         }
	         
	         return ret;
	     }
	
	     protected void onPostExecute(Boolean result) {
	    	 
	    	 mPD.dismiss();
	    	 if(result) {
	    		 mDevList = mService.getDeviceStats();
	    		 if(mDevList != null && mDevList.length > 0) {
	    			 
	    			 boolean hasChannels = false;
	    			 for(int i = 0; i < mDevList.length; ++i) {
	    				 if(mDevList[i].mHasChannelScan) {
	    					 hasChannels = true;
	    					 break;
	    				 }
	    			 }
	    			 
	    			 if(!hasChannels) {
	    				
	    				 // no channels, ask user to scan, if they don't.. we can't do much
	    				 
	    				 
	    				 //temp
	    				 if(mDevList.length > 0) {
	    					 mService.scanChannelsForDevice(mDevList[0].mID, new ServiceScanCB(true, mDevList[0].mID, "Scanning Device For Channels"));
	    					
	    				 }	
	    					 
	    				 
	    			 }
	    			 else
	    				 startNormalOperation();
	    		 }
	    		 // else pop up a dialog asking to scan again
	    	 }
	    	 // else pop up a dialog asking to wait further
	     }

    }
    
    
    private boolean getChannelActionLock(boolean tryLock) {
    	
    	boolean ret = false;
    	while(true) {
    		synchronized(mChannelActionLock) {
            
    			if(!mChannelActionLocked) {
    				mChannelActionLocked = true;
    				ret = true;
    			}
    		}
    		
    		if(ret || tryLock)
    			break;
    		
    		try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
    	}
    	
    	return ret;
    }
    
    private void releaseChannelActionLock() {
    	
    	synchronized(mChannelActionLock) {
        
    		mChannelActionLocked = false;
    	}
    }
    
    private ChannelCheckCB mChannelCheckCB = new ChannelCheckCB();
    class ChannelCheckCB implements AndroidServiceChannelStatusCallBack {

		@Override
		public void callBack(ChannelStatus result) {
		
			checkStatus(result);
			releaseChannelActionLock();
		}
    	
    }
    
    private ChannelActionCB mChannelActionCB = new ChannelActionCB();
    class ChannelActionCB implements AndroidServiceChannelStatusCallBack {
    
    	ChannelActionCB() {
    		
    	}
    	private ProgressDialog mProgress = null;
    	
    	public void showProgress(Channel channel) {
    		
    		String message = String.format("%s\n%d", channel.mName, channel.mVirtualChannel_Major);
    		if(channel.mVirtualChannel_Minor > 0)
    			message += String.format(".%d", channel.mVirtualChannel_Minor);
    		mProgress = ProgressDialog.show(mMe, "Changing Channel", message, true, false); 
    	}
    	
		@Override
		public void callBack(ChannelStatus ret) {
			
			if(mProgress != null && mProgress.isShowing()) {
				mProgress.dismiss();
				mProgress = null;
			}		
			
			checkStatus(ret);
			
			showCurrentChannel(true);
			
			mGuideBar.setVisibility(View.INVISIBLE);
				
			releaseChannelActionLock();
			
			mService.getCurrentChannelStatus(mChannelCheckCB);
		}
    
    }
    
    private void checkStatus(ChannelStatus status) {
    	
    	if(status.failedChange)
			Toast.makeText(mMe, "Failed to tune to the channel", Toast.LENGTH_LONG);
		else if(status.not_available)
			Toast.makeText(mMe, "The channel is not available at this time", Toast.LENGTH_LONG);
		else if(status.not_subscribed)
			Toast.makeText(mMe, "You are not subscibed to this channel", Toast.LENGTH_LONG);
		else if(status.not_available)
			Toast.makeText(mMe, "The Channel is Copy Protected", Toast.LENGTH_LONG);
		else if(status.copy_protected)
			Toast.makeText(mMe, "The Channel is Copy Protected", Toast.LENGTH_LONG);
    }
    
    class ServiceScanCB implements AndroidServiceScanCallBack {

    	ServiceScanCB(boolean showProgress, String progressTitle, String progressMessage) {
    		if(showProgress) {
    			mProgress = ProgressDialog.show(mMe, progressTitle, progressMessage, true, false); 
    		}
    	}
    	private ProgressDialog mProgress = null;
		@Override
		public void callBack(boolean ret) {
			
			if(mProgress != null) {
				mProgress.dismiss();
				mProgress = null;
			}
				
			if(ret)
				startNormalOperation();			
		}
    	
    }
    
    private LayoutParams mDefaultVideoViewSize = null;
    private void startNormalOperation() {
    	
    	// not sure about this
    	//mService.setChannel("wpvi", mChannelActionCB);
    	//String vidPath = String.format("udp://%s", mService.getTargetString());
    	//String vidPath = String.format("udp://@:%d", mService.getTargetPort());
    	//String vidPath = String.format("udp://@:%d", mService.getTargetPort());
    	//String vidPath = String.format("udp://192.168.1.10:%d", mService.getTargetPort());
    	String vidPath = String.format("http://192.168.1.112:8080");    	
    	//String vidPath = mService.getStreamTarget();
    	Uri uri = Uri.parse(vidPath);
    		mVideoView.setVideoURI(uri);
    		 MediaController mc = new MediaController(this, true);
    	        mc.setMediaPlayer(mVideoView);
    	        mc.setAnchorView(mVideoView);
    	        mVideoView.setMediaController(mc);
    	        mVideoView.requestFocus();
    	        mVideoView.start();
    	    //    mDefaultVideoViewSize = (LayoutParams) mVideoView.getLayoutParams();	
	
    	/*mVideoView.setVideoPath(vidPath);
    	mVideoView.setMediaController(new MediaController(this));
        mVideoView.requestFocus();
        mVideoView.start();*/
    	// create guide
    	//createGuide();
    	//showCurrentChannel(true);
    }
   

    private void createGuide() {
    	
    	List<DevChannel> ls = mService.getChannelList().getFullListSortedByNumber();
		final int count = ls.size();
		final Channel last = null;
		for(int i = 0; i < count; ++i) {
			final Channel chn = ls.get(i).mChannel;
			if(!chn.isEmpty()) {
				if(last == null || !last.equals(chn) ){
					GuideRow row = new GuideRow(this, chn, mService, mChannelActionCB);
					mGuide.addView(row,new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
				}
			}
		}
    }

    @Override
    public boolean onTouchEvent(MotionEvent me) {
        return gestureScanner.onTouchEvent(me);
    }
    
	@Override
	public boolean onDown(MotionEvent arg0) {
		
		mGuideBar.setVisibility(View.INVISIBLE);
		clearCurrentChannel();
		return false;
	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		
		if(Math.abs(velocityX) > Math.abs(velocityY)) {
			if(velocityX > 0) {
				showCurrentChannel(false);
				mGuideBar.setVisibility(View.VISIBLE);
			}
			else if(velocityX > 0) {
				clearCurrentChannel();
				mGuideBar.setVisibility(View.INVISIBLE);
			}
			else 
				return false;
		}
		else {
			if(velocityY > 0) 
				showCurrentChannel(true);
			else if(velocityY < 0)
				clearCurrentChannel();
			else
				return false;
		}
			
		return true;
	}

	@Override
	public void onLongPress(MotionEvent e) {
		
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		return false;
	}
 
	
	public void showCurrentChannel(boolean killOnDelay) {
		
		Channel channel = mService.getCurrentChannel();
		String chnText = "No channel set";
		if(null != channel) {
			chnText = String.format("%s\n%d", channel.mName, channel.mVirtualChannel_Major);
			if(channel.mVirtualChannel_Minor > 0)
				chnText += String.format(".%d", channel.mVirtualChannel_Minor);
		}
		
		if(mActionBar != null) {
			mActionBar.setTitle(chnText);
			mActionBar.show();
		}
		else {
			mCurrentChannel.setText(chnText);
			mInfoBar.setVisibility(View.VISIBLE);
		}
		
		if(killOnDelay)
			mInfoBar.postDelayed(hideInfoBar, HIDE_TIMEOUT);		
	}
	
	public void clearCurrentChannel() {
		
		if(mActionBar != null) 
			mActionBar.hide();
		else
			mInfoBar.setVisibility(View.INVISIBLE);
	}
	
	private Runnable hideInfoBar = new Runnable() {
	    public void run() {

	    	clearCurrentChannel();
	    }
	};
}