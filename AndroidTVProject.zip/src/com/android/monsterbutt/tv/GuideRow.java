package com.android.monsterbutt.tv;


import com.android.monsterbutt.tv.AndroidTVProjectActivity.ChannelActionCB;
import com.android.monsterbutt.tv.AndroidTVService.AndroidTVProjectBinder;
import com.android.monsterbutt.tvstuff.Channel;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class GuideRow extends android.widget.TableRow {

	private Button 		mStationButton;
	private Channel 	mChannel;
	private AndroidTVProjectBinder mBinder;
	private ChannelActionCB mChannelCB;
	public GuideRow(Context context, Channel channel, AndroidTVProjectBinder binder, ChannelActionCB channelActionCB) {
		super(context);
		
		mChannelCB = channelActionCB;
		mBinder = binder;
		mChannel = channel;
		LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View v = layoutInflater.inflate(R.layout.guiderow,this);
		
		mStationButton = (Button) v.findViewById(R.id.btnStation);		
		
		mStationButton.setText(String.format("%d\n%s", mChannel.mVirtualChannel_Major, mChannel.mName));
		mStationButton.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		onSetChannelButtonClick();
        	}
        });
	}

	private void onSetChannelButtonClick() {
		mChannelCB.showProgress(mChannel);
		mBinder.setChannel(mChannel.mName, mChannelCB);
	}
}
