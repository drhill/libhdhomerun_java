package com.android.monsterbutt.tv;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import android.os.AsyncTask;
import android.os.Looper;
import android.util.Log;

public class AndroidTVStreamer implements Runnable {

    private static final int SERVER_PORT=8888;

    private static final String TAG = "AndroidTVStreamer";
    private Thread thread;
    private boolean isRunning;
    private ServerSocket m_OutputSocket;
    
    private static int m_TS_PacketSize = 1024 * 32;
    private byte[] m_StreamBuffer = new byte[m_TS_PacketSize];
    private int    m_StreamBufferLength = 0;
    DatagramSocket  m_InputSocket = null;
    boolean		   m_InputBound = false;
    InetAddress    m_DeviceAddr = null;
    int			   m_TargetPort = 0;
    
    private static int RECV_TIMEOUT = 25; 

    public AndroidTVStreamer(SocketAddress streamSocketAddr, int targetPort, InetAddress deviceIP) {

    	m_DeviceAddr = deviceIP;
    	m_TargetPort = targetPort;
    	try {
    		m_InputSocket = new DatagramSocket (targetPort);
    		m_InputSocket.setBroadcast(true);
    		m_InputSocket.setReceiveBufferSize(m_TS_PacketSize*3);
    		m_InputSocket.setSoTimeout(1);
    		m_InputBound = m_InputSocket.isBound();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
        // Create listening socket
        try {
           m_OutputSocket = new ServerSocket(SERVER_PORT, 0, InetAddress.getByAddress(new byte[] {127,0,0,1}));        	 
           m_OutputSocket.setSoTimeout(5000);
        } catch (UnknownHostException e) { // impossible
        } catch (IOException e) {
          Log.e(TAG, "IOException initializing server", e);
        }

    }

    public void start() {
        thread = new Thread(this);
        thread.start();
    }

    public void stop() {
        isRunning = false;
        thread.interrupt();
        try {
            thread.join(5000);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
    }

    @Override
      public void run() {
        Looper.prepare();
        isRunning = true;
        while (isRunning) {
          try {
            Socket client = m_OutputSocket.accept();
            if (client == null) {
              continue;
            }
            Log.d(TAG, "client connected");

            StreamToMediaPlayerTask task = new StreamToMediaPlayerTask(m_InputSocket, client);
            if (task.processRequest(RECV_TIMEOUT)) {
                task.execute();
            }

          } catch (SocketTimeoutException e) {
            // Do nothing
          } catch (IOException e) {
            Log.e(TAG, "Error connecting to client", e);
          }
        }
        Log.d(TAG, "Proxy interrupted. Shutting down.");
    }

    private class StreamToMediaPlayerTask extends AsyncTask<String, Void, Integer> {

    	DatagramSocket recSocket;
        Socket client;

        public StreamToMediaPlayerTask(DatagramSocket recSocket, Socket client) {
        	this.recSocket = recSocket;
            this.client = client;
        }

        public boolean processRequest(int timeout) {

            long endTime = System.currentTimeMillis() + timeout;
            
    		while (true) {

    			DatagramPacket p = new DatagramPacket(m_StreamBuffer, m_StreamBuffer.length);
    			try {
    				recSocket.receive(p);
				} catch(SocketTimeoutException e)
				{
					
					continue;
				}
				catch (IOException e) {
					e.printStackTrace();
					return false;
				}
				int pLen = p.getLength();
    			if (pLen > 0  && pLen != m_StreamBuffer.length) {
    				InetSocketAddress remoteAddr = (InetSocketAddress)p.getSocketAddress();
    				
    				m_StreamBufferLength = pLen;
    				return true;
    			}

    	//		if(endTime <= System.currentTimeMillis())
    	//			return false;
    		}
        }

        @Override
        protected Integer doInBackground(String... params) {

            String mime_type = "video/mp2t";
            // Create HTTP header
            String headers = "HTTP/1.0 200 OK\r\n";
            headers += "Content-Type: " + mime_type + "\r\n";
            headers += "Content-Length: " + m_StreamBufferLength  + "\r\n";
            headers += "Connection: close\r\n";
            headers += "\r\n";

            // Begin with HTTP header
            int cbToSend = m_StreamBufferLength;
            OutputStream output = null;
            try {
                output = new BufferedOutputStream(client.getOutputStream(), m_TS_PacketSize);                           
                output.write(headers.getBytes());

                // Loop as long as there's stuff to send
                if (isRunning && cbToSend>0 && !client.isClosed()) {
                	
                        output.write(m_StreamBuffer, 0, cbToSend);
                        output.flush();
                }
            }
            catch (SocketException socketException) {
                Log.e(TAG, "SocketException() thrown, proxy client has probably closed. This can exit harmlessly");
            }
            catch (Exception e) {
                Log.e(TAG, "Exception thrown from streaming task:");
                Log.e(TAG, e.getClass().getName() + " : " + e.getLocalizedMessage());
                e.printStackTrace();                
            }

            // Cleanup
            try {
                if (output != null) {
                    output.close();
                }
                client.close();
            }
            catch (IOException e) {
                Log.e(TAG, "IOException while cleaning up streaming task:");                
                Log.e(TAG, e.getClass().getName() + " : " + e.getLocalizedMessage());
                e.printStackTrace();                
            }

            return 1;
        }

    }


	public String getServerTargetAddress() {
		return String.format("http://127.0.0.1:%d", SERVER_PORT);
	}
}
