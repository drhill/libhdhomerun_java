package com.android.monsterbutt.tv;


import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import com.android.monsterbutt.tvstuff.Channel;
import com.android.monsterbutt.tvstuff.DeviceMgr;
import com.android.monsterbutt.tvstuff.DeviceMgr_ChannelList;
import com.android.monsterbutt.tvstuff.DeviceMgr.deviceStatus;
import com.android.monsterbutt.tvstuff.DeviceMgr_ChannelList.DevChannel;
import com.android.monsterbutt.tvstuff.TuningDevice.ChannelStatus;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.MulticastLock;
import android.net.wifi.WifiManager.WifiLock;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;

public class AndroidTVService extends Service {

	final static private String	mLogName = "AndroidTVProject";
	
	private Context				mContext = null;
	
	private static int	        BASE_PORT_ADDR = 1000;
	private String				mDeviceTarget = "";
	private int 				mDeviceTargetPort = BASE_PORT_ADDR;
	private InetAddress			mDeviceTargetIP = null;
	private InetAddress			mDeviceIP = null;
	private static final String	mDeviceMgrLck = "DeviceMgrLock";
	private DeviceMgr			mDeviceMgr = null;
	private DeviceMgr_ChannelList mChannelList = null;
	private DevChannel			mCurrentChannel = null;
	
	private WakeLock			mDataWakeLock = null;
	
	private NotificationManager mNM;
    // Unique Identification Number for the Notification.
    // We use it on Notification start, and to cancel it.
    private int NOTIFICATION = R.string.ongoing_notification;
    
    MulticastLock 			mCastLock;
    WifiLock				mWifiLock;
    
    AndroidTVStreamer		mStreamer = null;

    
	 @Override
	    public void onCreate() {
	        mNM = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
	        
	        mContext = this.getApplicationContext();
	        
	        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
	        mDataWakeLock  = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AnroidTVProject_DataWakeLock");
	        WifiManager wm = (WifiManager)getSystemService(Context.WIFI_SERVICE);
	        mCastLock =  wm.createMulticastLock("AndroidTVProject_MCastLock");	      	        
	        mWifiLock = wm.createWifiLock("AndroidTVProject_WifiLock");
	        
	        setLocalTargetAddress();
	        
	        try {
				mDeviceIP = InetAddress.getByAddress(new byte[] {(byte) 192,(byte) 168,0,10});
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        mStreamer = new AndroidTVStreamer(new InetSocketAddress(mDeviceTargetIP, 0), mDeviceTargetPort, mDeviceIP);

	        // Display a notification about us starting.  We put an icon in the status bar.
	        showOnGoingNotification("");
	        
			
			new DeviceMgrCreate().execute(new Void[0]);
	    }
	    
		 private class DeviceMgrCreate extends AsyncTask<Void, Void, DeviceMgr> {
		     protected DeviceMgr doInBackground(Void... params) {
		    	 
		    	 acquireDeviceLocks();
		    	 boolean needDev = false;
		    	 synchronized(mDeviceMgrLck) {
		    		 needDev = (mDeviceMgr == null);
		    	 }
		    	 if(needDev)
		    		 return new DeviceMgr(mContext);
		    	 return null;
		     }
		
		     protected void onPostExecute(DeviceMgr result) {
		    	 synchronized(mDeviceMgrLck) {
		    		 if(mDeviceMgr == null && result != null) {
		    			 mDeviceMgr = result;
		    			 mChannelList = mDeviceMgr.getChannelList();
		    			 //mStreamer.start();
		    		 }
		    	 }
		    	 releaseDeviceLocks();
		     }

		 }
		 
		 private void acquireDeviceLocks() {
		 
			 // these locks are ref counted by default
			mDataWakeLock.acquire();
	        mWifiLock.acquire();
	        mCastLock.acquire();	        
		 }
		 
		 private void releaseDeviceLocks() {
			 
			 if(mDataWakeLock.isHeld())
				 mDataWakeLock.release();
			 if(mWifiLock.isHeld())
				 mWifiLock.release();
			 if(mDataWakeLock.isHeld())
				 mCastLock.release();
		 }
		 
		private void setLocalTargetAddress()
		{
			
			try {
				for(Enumeration<NetworkInterface> list = NetworkInterface.getNetworkInterfaces(); list.hasMoreElements();)
				{
				 	NetworkInterface i = list.nextElement();
				 	for(Enumeration<InetAddress> adds = i.getInetAddresses(); adds.hasMoreElements(); ) {
				    	InetAddress a = adds.nextElement(); 
				    	
				    	if(a.isLoopbackAddress() || a.getHostAddress().equals("255.255.255.255") || a.getHostAddress().equals("0.0.0.0"))
				    		continue;
					
				    	// only ipv4
				    	if(a.getAddress().length > 4)
				    		continue;

				    	mDeviceTargetIP = a;
				    	byte[] bytes = a.getAddress();
				    	mDeviceTarget = String.format("%d.%d.%d.%d:%d", ((int)bytes[0] + 256) % 256,
														    			((int)bytes[1] + 256) % 256,
														    			((int)bytes[2] + 256) % 256,
														    			((int)bytes[3] + 256) % 256,
														    			mDeviceTargetPort);
				    	mDeviceTargetPort = BASE_PORT_ADDR + ((int)bytes[3] + 256) % 256;
				    	break;
				 	}
				}
			} catch (SocketException e) {
				e.printStackTrace();
			}
			
		}
		 
		 private class DeviceMgrScan extends AsyncTask<String, Void, Boolean> {
			 
			 private AndroidServiceScanCallBack mCB = null;
			 public DeviceMgrScan(AndroidServiceScanCallBack cb) {
				 mCB = cb;
			 }
		     protected Boolean doInBackground(String... params) {
		        
		    	 acquireDeviceLocks();
		    	 Boolean ret = true;
		    	 for(int i = 0; i < params.length; ++i) {
		    		 
		    		 ret &= mDeviceMgr.scanChannelsForDevice(params[i]);
		    	 }
		    	 releaseDeviceLocks();
		    		 
		    	 return ret;
		     }
		
		     protected void onPostExecute(Boolean result) {
		    	
		    	 //risky not threadsafe
		    	 if(result)
		    		 mChannelList = mDeviceMgr.getChannelList();
		    	 
		    	 if(mCB != null)
		    		 mCB.callBack(result);
		     }

		 }
		 
		 private class DeviceMgrDestroy extends AsyncTask<DeviceMgr,Void,Boolean> {

			@Override
			protected Boolean doInBackground(DeviceMgr... params) {
				params[0].releaseResources();
				return null;
			}
			 
		 }
		 
		 private class DeviceMgrSetChannel extends AsyncTask<List<DevChannel>, Void, ChannelStatus> {
			 
			 private AndroidServiceChannelStatusCallBack mCB = null;
			 public DeviceMgrSetChannel(AndroidServiceChannelStatusCallBack cb) {
				 mCB = cb;
			 }
		     protected ChannelStatus doInBackground(List<DevChannel>... params) {
		        
		    	 acquireDeviceLocks();
		    	 ChannelStatus ret = setVirtualChannelFromList(params[0]);
		    	 releaseDeviceLocks();
		    		 
		    	 return ret;
		     }
		     
		    // for async task
		    private ChannelStatus setVirtualChannelFromList(List<DevChannel> ls) {
		    	
		    	ChannelStatus status = new ChannelStatus();
		    	// scan list, keep the current tuner if we can, if not, change channel and free the current tuner
				Iterator<DevChannel> iter = ls.iterator();
				while(mCurrentChannel != null && iter.hasNext()) {
					DevChannel chan = iter.next();
					if(chan.mDevice.getID().compareTo(mCurrentChannel.mDevice.getID()) == 0) {
						
						status = chan.mDevice.setChannel(mDeviceTarget, chan.mChannel);
						if(!status.failedChange) 
							mCurrentChannel = chan;
						return status;
						
					}
				}
				
				// we couldn't use the current tuner for whatever reason
				// just loop through and throw whatever at the wall till it sticks
				iter = ls.iterator();
				while(iter.hasNext()) {
					DevChannel chan = iter.next();
					
					status = chan.mDevice.setChannel(mDeviceTarget, chan.mChannel);
					if(!status.failedChange) {
						
						if(mCurrentChannel != null && chan.mDevice.getID().compareTo(mCurrentChannel.mDevice.getID()) != 0)
							mCurrentChannel.mDevice.releaseResources();
						mCurrentChannel = chan;
						return status;
					}
				}

				return status;
		    }
		
		     protected void onPostExecute(ChannelStatus result) {
		    	
		    	 if(mCB != null)
		    		 mCB.callBack(result);
		     }

		 }
		 
		 private class DeviceMgrCheckChannel extends AsyncTask<DevChannel, Void, ChannelStatus> {
			 
			 private AndroidServiceChannelStatusCallBack mCB = null;
			 
			 public DeviceMgrCheckChannel(AndroidServiceChannelStatusCallBack cb) {
				 mCB = cb;
			 }
		     protected ChannelStatus doInBackground(DevChannel... params) {
		        
		    	 acquireDeviceLocks();
		    	 DevChannel chn = (DevChannel) params[0];
		    	 ChannelStatus ret = chn.mDevice.getChannelStatus(chn.mChannel); 
		    	 releaseDeviceLocks();
		    		 
		    	 return ret;
		     }
		     
		     protected void onPostExecute(ChannelStatus result) {
			    	
		    	 if(mCB != null)
		    		 mCB.callBack(result);
		     }
		 }

	    @Override
	    public int onStartCommand(Intent intent, int flags, int startId) {
	        Log.i(mLogName, "AndroidTVService - Received start id " + startId + ": " + intent);
	      
	        // We want this service to continue running until it is explicitly
	        // stopped, so return sticky.
	        return START_STICKY;
	    }

	    @Override
	    public void onDestroy() {
	    	
	    	mStreamer.stop();
	    	mStreamer = null;
	        // Cancel the persistent notification.
	    	mNM.cancel(NOTIFICATION);
	    	
	    	 synchronized(mDeviceMgrLck) {
	    		 if(mDeviceMgr != null)
	    			 new DeviceMgrDestroy().execute(mDeviceMgr);
	    	 }
    		mDeviceMgr = null;
	    }
	    
	    private void showOnGoingNotification(CharSequence text) {
	        // Set the icon, scrolling text and timestamp
	        Notification notification = new Notification(R.drawable.icon, text, System.currentTimeMillis());

	        // The PendingIntent to launch our activity if the user selects this notification
	        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, new Intent(this, AndroidTVProjectActivity.class), 0);

	        // Set the info for the views that show in the notification panel.
	        notification.setLatestEventInfo(this, getText(R.string.service_notification_label), text, contentIntent);
	        notification.flags = Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;

	        // Send the notification.
	        mNM.notify(NOTIFICATION, notification);
	    }

	    private void showEventNotification(CharSequence text) {
	    	
	    	Notification notification = new Notification(R.drawable.icon, text, System.currentTimeMillis());
			notification.flags |= Notification.FLAG_AUTO_CANCEL;
			
			//Intent notificationIntent = new Intent(mContext, com.android.monster.plugin.googlevoice.ProfileActivity.class);
			PendingIntent contentIntent = PendingIntent.getActivity(this, 0, new Intent(this, AndroidTVProjectActivity.class), 0);
			notification.setLatestEventInfo(this, getText(R.string.service_notification_label), text, contentIntent);
			notification.flags = Notification.FLAG_AUTO_CANCEL;
			
			mNM.notify(R.string.event_notification, notification);
	    }
	    
	    @Override
	    public IBinder onBind(Intent intent) {
	        return mBinder;
	    }
	    public class AndroidTVProjectBinder extends Binder {
	    	
	    	boolean isReady() {
	    		return isServiceReady();
	    	}
	    	
	    	deviceStatus[] getDeviceStats() {
	    		
	    		if(isReady()) 	    			
	    			return mDeviceMgr.getDeviceStats();		    		
	    		
	    		return null;
	    	}
	    	
	    	boolean scanChannelsForDevice(String id, AndroidServiceScanCallBack cb) {
	    		
	    		boolean ret = false;
	    		if(isReady()) {
	    			String[] lsID = new String[1];
	    			lsID[0] = id;
	    			new DeviceMgrScan(cb).execute(lsID);
	    			return true;
	    		}
	    		
	    		return ret;
	    	}
	    	
	    	DeviceMgr_ChannelList getChannelList() {
	    		return mChannelList;
	    	}
	    	
	    	List<Channel> getMatchingChannels(int number) {
	    		return getTypeAheadChannel(number);
	    	}
	    	
	    	List<Channel> getMatchingChannels(final String name) {
	    		return getTypeAheadChannel(name);
	    	}
	    	
	    	final String getTargetString() {
	    		return mDeviceTarget;
	    	}
	    	
	    	boolean setChannel(final String name, AndroidServiceChannelStatusCallBack cb) {
	    		return setChannelFromName(name, cb);
	    	}
	    	
	    	boolean setChannel(int number, AndroidServiceChannelStatusCallBack cb) {
	    		return setChannelFromVirtualNumber(number, cb);
	    	}
	    	
	    	boolean setNextChannel(AndroidServiceChannelStatusCallBack cb) {	    		
	    		return setNextVirtualChannel(cb);
	    	}
	    	
	    	boolean setPreviousChannel(AndroidServiceChannelStatusCallBack cb) {
	    		return setPreviousVirtualChannel(cb);	
	    	}

			public Channel getCurrentChannel() {
				if(mCurrentChannel != null)
					return mCurrentChannel.mChannel;
				return null;
			}

			public boolean getCurrentChannelStatus(AndroidServiceChannelStatusCallBack cb) {
				
				return getCurrentChnStatus(cb);
			}

			public String getStreamTarget() {
				
				if(mStreamer != null)
					return mStreamer.getServerTargetAddress();
				return "";
			}
	    }

	    private final IBinder mBinder = new AndroidTVProjectBinder();

	    private boolean isServiceReady() {
	    	boolean ret;
    		synchronized(mDeviceMgrLck) {
    			ret = (null != mDeviceMgr);
    		}
    		
    		return ret;
	    }
	    
	    	    
	    private List<Channel> getTypeAheadChannel(int number) {
	    	
	    	List<Channel> nums = new ArrayList<Channel>();
	    	if(isServiceReady() && mChannelList != null && mCurrentChannel != null) {
    			
    			// this doesn't really do major/minor yet
    			nums = mChannelList.getChannelsThatStartWithNumber(number);
	    	}
	    	
	    	return nums;
	    }
	    
	    private List<Channel> getTypeAheadChannel(final String name) {
	    	
	    	List<Channel> names = new ArrayList<Channel>();
	    	if(isServiceReady() && mChannelList != null) {
    			
    			// this doesn't really do major/minor yet
    			names = mChannelList.getChannelsThatStartWithName(name);
	    	}
	    	
	    	return names;
	    }
	    
	    private boolean setChannelFromName(final String name, AndroidServiceChannelStatusCallBack cb) {
	    	
	    	if(isServiceReady() && mChannelList != null) {
    			
    			// this doesn't really do major/minor yet
    			List<DevChannel> names = mChannelList.getDevChannelsThatStartWithName(name);
    			new DeviceMgrSetChannel(cb).execute(names);
    			return true;
	    	}    		
    		return false;
	    }
	    
	    private boolean setChannelFromVirtualNumber(int number, AndroidServiceChannelStatusCallBack cb) {
	    	
	    	if(isServiceReady() && mChannelList != null) {
    			
    			// this doesn't really do major/minor yet
    			List<DevChannel> nums = mChannelList.getDevChannelsThatStartWithNumber(number);
    			new DeviceMgrSetChannel(cb).execute(nums);
    			return true;
	    	}    		
    		return false;
	    }
	    private boolean setNextVirtualChannel(AndroidServiceChannelStatusCallBack cb) {
	    	
	    	if(isServiceReady() && mChannelList != null && mCurrentChannel != null) {
    			
    			// this doesn't really do major/minor yet
    			List<DevChannel> next = mChannelList.getNextChannelNumberList(mCurrentChannel.mChannel.mVirtualChannel_Major);
    			new DeviceMgrSetChannel(cb).execute(next);
    			return true;
	    	}    		
    		return false;
	    }
	    
	    private boolean getCurrentChnStatus(AndroidServiceChannelStatusCallBack cb) {
	    	
	    	if(isServiceReady() && mChannelList != null && mCurrentChannel != null) {
	    		new DeviceMgrCheckChannel(cb).execute(mCurrentChannel);
	    	}
	    	return false;
	    }
	    private boolean setPreviousVirtualChannel(AndroidServiceChannelStatusCallBack cb) {
	    	
	    	if(isServiceReady() && mChannelList != null && mCurrentChannel != null) {
    			
    			// this doesn't really do major/minor yet
    			List<DevChannel> prev = mChannelList.getPreviousChannelNumberList(mCurrentChannel.mChannel.mVirtualChannel_Major);
    			new DeviceMgrSetChannel(cb).execute(prev);
    			return true;
	    	}    		
    		return false;
	    }
 
	    public interface AndroidServiceScanCallBack {
	    	public void callBack(boolean ret);
	    }
	    
	    public interface AndroidServiceChannelStatusCallBack {
	    	public void callBack(ChannelStatus result);
	    }
	    
}
