package com.android.monsterbutt.tvstuff;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import android.content.Context;

import com.silicondust.libhdhomerun.HDHomerun_Discover;
import com.silicondust.libhdhomerun.HDHomerun_Pkt;
import com.silicondust.libhdhomerun.HDHomerun_Sock;
import com.silicondust.libhdhomerun.HDHomerun_Discover.hdhomerun_discover_device_t;
import com.silicondust.libhdhomerun.HDHomerun_Sock.hdhomerun_local_ip_info_t;

public class DeviceMgr {

	private List<TuningDevice> mDevices = new ArrayList<TuningDevice>();
	private Context mContext = null;
	private DeviceMgr_ChannelList mMgrChannelList = null;
	
	public class deviceStatus {
		
		public deviceStatus(String id, String name, int tunerCount, boolean hasChannelScan) {
			mID = id;
			mName = name;
			mTunerCount = tunerCount;
			mHasChannelScan = hasChannelScan;
		}
		
		public String mName = "";
		public String mID   = "";
		public boolean mHasChannelScan = false;
		public int mTunerCount = 0;
	};
	
	public DeviceMgr(Context context) {
		
		mContext = context;
		scanForHDHomerunDevices();
		buildChannelList();
	}
	
	private void scanForHDHomerunDevices() {
		
		hdhomerun_local_ip_info_t[] ip_info_list = new hdhomerun_local_ip_info_t[2];
		HDHomerun_Sock.hdhomerun_local_ip_info(ip_info_list, 2);
		String ip = HDHomerun_Sock.IPAddr_IntToString(ip_info_list[0].ip_addr);
		hdhomerun_discover_device_t[] result_list = new hdhomerun_discover_device_t[64];
		int count = HDHomerun_Discover.hdhomerun_discover_find_devices_custom(0, HDHomerun_Pkt.HDHOMERUN_DEVICE_TYPE_TUNER, HDHomerun_Pkt.HDHOMERUN_DEVICE_ID_WILDCARD, result_list, 64);
		for(int i = 0; i < count; ++i) {
			mDevices.add(new HDHomerun_TuningDevice(mContext, ip, result_list[i]));
		}
			
	}
		
	
	public boolean scanChannelsForDevice(String id) {
		
		Iterator<TuningDevice> iter = mDevices.iterator();
		while(iter.hasNext()) {
			final TuningDevice dev = iter.next();
			if(0 == id.compareTo(dev.getID())) {
				boolean ret =  dev.scanChannels();
				if(ret)
					buildChannelList();
				return ret;
			}
		}
		
		return false;
	}
	
	public deviceStatus[] getDeviceStats() {
		
		List<deviceStatus> ls = new ArrayList<deviceStatus>();
		
		Iterator<TuningDevice> iter = mDevices.iterator();
		while(iter.hasNext()) {
			final TuningDevice dev = iter.next();
			ls.add(new deviceStatus(dev.getID(), dev.getName(), dev.getTunerCount(), dev.hasChannelScanDone()));
		}

		if(ls.size() == 0)
			return null;
		deviceStatus[] ret = new deviceStatus[ls.size()];
		for(int i = 0; i < ls.size(); ++i)
			ret[i] = ls.get(i);
		return ret;
	}

	public void releaseResources() {
		
		Iterator<TuningDevice> iter = mDevices.iterator();
		while(iter.hasNext()) {
			final TuningDevice dev = iter.next();
			dev.releaseResources();		
		}
		
	}

	private void buildChannelList() {
		
		mMgrChannelList = new DeviceMgr_ChannelList(mDevices);
		
	}
	
	public DeviceMgr_ChannelList getChannelList() {
		return mMgrChannelList;
	}
}
