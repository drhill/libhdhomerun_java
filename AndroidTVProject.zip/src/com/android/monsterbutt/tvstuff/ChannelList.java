package com.android.monsterbutt.tvstuff;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import android.content.Context;

import com.android.monsterbutt.tvstuff.Channel;

public class ChannelList {

	private Context mContext = null;
	private static final String CHANNELLIST_FILE_EXT = ".chl";
	
	private List<Channel> mChannels = new ArrayList<Channel>();
	
	public ChannelList(Context context, String fileName, List<Channel> channels) {
		
		mContext = context;
		if(!fileName.endsWith(CHANNELLIST_FILE_EXT))
			fileName += CHANNELLIST_FILE_EXT;
		
		mChannels = channels;
		
		try {
			FileOutputStream out = mContext.openFileOutput(fileName, Context.MODE_PRIVATE);
			DataOutputStream dos = new DataOutputStream(out);
			dos.writeInt(mChannels.size());
			Iterator<Channel> iter = mChannels.iterator();
			while(iter.hasNext()) {
				final Channel channel = iter.next();
				channel.writeToStream(dos);
			}
			
			dos.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			mChannels = null;
		} catch (IOException e) {
			e.printStackTrace();
			mChannels = null;			
		}
		
	}
	
	public ChannelList(Context context, String fileName) {
		
		mContext = context;
		if(!fileName.endsWith(CHANNELLIST_FILE_EXT))
			fileName += CHANNELLIST_FILE_EXT;
		
		try {
			FileInputStream in = mContext.openFileInput(fileName);
			DataInputStream dis = new DataInputStream(in);
			
			int channelCnt = dis.readInt();
			for(int i = 0; i < channelCnt; ++i) {
				try {
					Channel chn = new Channel(dis);
					mChannels.add(chn);
				} catch (IOException e) {
					mChannels = null;
					return;
				}
			}
			
			dis.close();
			in.close();
		} catch (FileNotFoundException e) {
			mChannels = null;
		} catch (IOException e) {
			mChannels = null;
		}
	}

	public int getChannelCount() {
		
		if(null == mChannels)
			return 0;
		return mChannels.size();
	}

	public Channel getChannelAtIndex(int i) {
		
		if(i >= mChannels.size() || i < 0)
			return null;
		return mChannels.get(i);
	}
	
}
