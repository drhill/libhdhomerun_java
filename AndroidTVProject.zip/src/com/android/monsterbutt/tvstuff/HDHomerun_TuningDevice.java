package com.android.monsterbutt.tvstuff;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;

import com.android.monsterbutt.tvstuff.ChannelList;
import com.silicondust.libhdhomerun.HDHomerun_Channels;
import com.silicondust.libhdhomerun.HDHomerun_Debug;
import com.silicondust.libhdhomerun.HDHomerun_Device;
import com.silicondust.libhdhomerun.HDHomerun_Discover.hdhomerun_discover_device_t;
import com.silicondust.libhdhomerun.HDHomerun_Types.hdhomerun_channelscan_result_t;
import com.silicondust.libhdhomerun.HDHomerun_Types.hdhomerun_tuner_vstatus_t;

public class HDHomerun_TuningDevice implements TuningDevice{

	public static final String DEVICE_FILE_EXT = ".dvc";
	
	private Context mContext = null;
	private String mID = "";
	private String mName = "";
	private ChannelList mChannels = null;
	private int mTunerCount = 0;
	private int mTunerIP = 0;
	private String mCurrentTarget = "";
	private boolean mHasTunerLock = false;
	private boolean mHasChannelScan = false;
	private String mInterfaceIP = "";
	private HDHomerun_Debug mDbg = new HDHomerun_Debug();
	private HDHomerun_Device mDevice = null;
	
	public HDHomerun_TuningDevice(Context context, String interfaceIP, hdhomerun_discover_device_t device) {
		
		mContext = context;
		try {
			mID = String.format("%08X", device.device_id);
			mName = "FixMe";
			mDevice = new HDHomerun_Device(mID, mDbg);
			mDevice.set_device(device.device_id, device.ip_addr);
			mTunerIP = device.ip_addr;
			mTunerCount = device.tuner_count;
			mInterfaceIP = interfaceIP;
			
			mHasChannelScan = getChannelListFromFile();
				
		} catch (Exception e) {
			mDevice = null;
		}
	}
	
	public void releaseResources() {
		
		if(mHasTunerLock) {			
			releaseLockedTuner();
			mDevice.set_tuner_target("none");
		}
	}
	
	public ChannelStatus setChannel(final String target, Channel channel) {
		
		ChannelStatus status = new ChannelStatus();	
		if( getFreeTuner()) {
			// if we didn't previously have a lock we set the target, we only need to do this once
			// a tuner, which we should now hold until we shut down, or do funny business
			boolean ret = true;
			if(mCurrentTarget.compareTo(target) != 0)
				ret = (0 <= mDevice.set_tuner_target(target));
			
			// if all is well, set channel
			if(ret && 0 <= mDevice.set_tuner_vchannel(String.format("%d", channel.mVirtualChannel_Major))) {
										
				status = getChannelStatus(channel);
			}			
		}		
		
		return status;
	}
	
	public ChannelStatus getChannelStatus(Channel channel) {
	
		ChannelStatus status = new ChannelStatus();
		hdhomerun_tuner_vstatus_t vstatus = new hdhomerun_tuner_vstatus_t();
		if(0 < mDevice.get_tuner_vstatus(null, vstatus)) {
			
			status.failedChange = false;
			String vChannel = String.format("%d", channel.mVirtualChannel_Major);
			if(channel.mVirtualChannel_Minor > 0)
				vChannel += String.format(".%d", channel.mVirtualChannel_Minor);
			status.validChange = (vstatus.name.compareTo(channel.mName) == 0 || vstatus.vchannel.compareTo(vChannel) == 0);
			status.not_available = vstatus.not_available;
			status.not_subscribed = vstatus.not_subscribed;
			status.copy_protected = vstatus.copy_protected;
		}
		
		return status;
	}
	
	private boolean getChannelListFromFile() {
		
		boolean ret = false;
		if(mID.length() > 0) {
			mChannels = new ChannelList(mContext, mID);
				
			ret = (mChannels != null && mChannels.getChannelCount() > 0);
		}
		
		return ret;
	}
	
	public boolean hasChannelScanDone() {
		return mHasChannelScan;
	}
	
	public final ChannelList getChannelList() {
		return mChannels;
	}
	
	private boolean getFreeTuner() {
	
	
		if(!mHasTunerLock) {
			
			for(int i = 0; i < mTunerCount; ++i) {
				mDevice.set_tuner(i);
				if(mDevice.tuner_lockkey_request(null) > 0) {
					
					mHasTunerLock = true;
					break;
				}
				else {
					// see if this device actually owns the lock, if so, force a release and reacuire
					StringBuilder powner = new StringBuilder();
					mDevice.get_tuner_lockkey_owner(powner);
					if(mInterfaceIP.compareTo(new String(powner)) == 0) {
						if(0 < mDevice.tuner_lockkey_force()) {
							if(mDevice.tuner_lockkey_request(null) > 0) {
								
								mHasTunerLock = true;
								break;
							}
						}
					}
				}
			}
		}
		
		return mHasTunerLock;
	}
	
	private void releaseLockedTuner() {
		
		if(mHasTunerLock) {
			mDevice.tuner_lockkey_release();
			mHasTunerLock = false;
		}			
	}
	
	private static void writeToFileAndScreen(FileOutputStream fp, String str) {
		
		System.out.print(str);
		if(fp != null) {
			try {
				fp.write(str.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public boolean scanChannels() {

		if(!getFreeTuner())
			return false;
		
		StringBuilder channelmap = new StringBuilder();
		if (mDevice.get_tuner_channelmap(channelmap) <= 0) {
			return false;
		}

		String channelmap_scan_group = HDHomerun_Channels.hdhomerun_channelmap_get_channelmap_scan_group(new String(channelmap));
		if (null == channelmap_scan_group || channelmap_scan_group.length() == 0) {
			return false;
		}

		if (mDevice.channelscan_init(channelmap_scan_group) <= 0) {
			return false;
		}
		
		List<Channel> channels = new ArrayList<Channel>();
		
		FileOutputStream fp = null;
		/*try {
			fp = mContext.openFileOutput(String.format("%s.scanlist", mID), Context.MODE_PRIVATE);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		int ret = 0;
		while (true) {
			hdhomerun_channelscan_result_t result = new hdhomerun_channelscan_result_t();
			ret = mDevice.channelscan_advance(result);
			if (ret <= 0) {
				break;
			}

			writeToFileAndScreen(fp, String.format("SCANNING: %d (%s)\n", result.frequency, result.channel_str
			));

			ret = mDevice.channelscan_detect(result);
			if (ret < 0) {
				break;
			}
			if (ret == 0) {
				continue;
			}

			writeToFileAndScreen(fp, String.format("LOCK: %s (ss=%d snq=%d seq=%d)\n",
					result.status.lock_str, result.status.signal_strength,
					result.status.signal_to_noise_quality, result.status.symbol_error_quality
				));

			if (result.transport_stream_id_detected) {
				writeToFileAndScreen(fp, String.format("TSID: 0x%04X\n", result.transport_stream_id));
			}

			for (int i = 0; i < result.program_count; i++) {
				
				Channel channel = new Channel(result.programs[i]);
				channels.add(channel);
				writeToFileAndScreen(fp, String.format("PROGRAM %s\n", result.programs[i].program_str));
			}
		}
		
		releaseLockedTuner();

		if(ret >= 0) {
			mChannels = new ChannelList(mContext, mID, channels);
			return true;
		}
		
		return false;
	}

	public String getID() {
		return mID;
	}

	public String getName() {
		return mName;
	}
	
	public int getTunerCount() {
		return mTunerCount;
	}
	
}
