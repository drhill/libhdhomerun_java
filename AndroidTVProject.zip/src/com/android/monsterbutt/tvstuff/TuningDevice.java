package com.android.monsterbutt.tvstuff;

public interface TuningDevice {

	public enum eTunerType {
		unknown,
		cableCard
	};
	
	public static class ChannelStatus {
		
		public boolean failedChange = true;
		public boolean validChange = false;
		public boolean not_subscribed = false;
		public boolean copy_protected = false;
		public boolean not_available = false;
		
	}
	
	public ChannelList getChannelList();

	public String getID();
	public String getName();

	public boolean hasChannelScanDone();
	public boolean scanChannels();

	public int getTunerCount();

	public void releaseResources();
	
	public ChannelStatus setChannel(final String target, Channel channel);

	public ChannelStatus getChannelStatus(Channel channel);
	
}
