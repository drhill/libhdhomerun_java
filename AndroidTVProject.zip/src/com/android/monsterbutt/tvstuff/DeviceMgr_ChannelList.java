package com.android.monsterbutt.tvstuff;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class DeviceMgr_ChannelList {
	
	public class DevChannel {
		
		public DevChannel(TuningDevice dev, Channel channel) {
			mDevice = dev;
			mChannel = channel;
		}
		public TuningDevice mDevice;
		public Channel		mChannel;
		
		@Override
		public boolean equals(Object obj) {
		       if (this == obj)
		           return true;
		       if (obj == null)
		           return false;
		       if (getClass() != obj.getClass())
		           return false;
		       return this.equals((DevChannel) obj);
		   }
		
		public boolean equals(DevChannel o) {
			
			if(0 != mChannel.mName.compareTo(o.mChannel.mName))
				return false;
			else if(mChannel.mVirtualChannel_Major != o.mChannel.mVirtualChannel_Major)
				return false;
			else if(mChannel.mVirtualChannel_Minor != o.mChannel.mVirtualChannel_Minor)
				return false;
			return true;
		}
	}
	
	List<DevChannel> mRawList = new ArrayList<DevChannel>();
	List<DevChannel> mSortedVNumber = new ArrayList<DevChannel>();
	List<Integer>		 mIndexVNumber = new ArrayList<Integer>();
	List<DevChannel> mSortedName = new ArrayList<DevChannel>();
	List<Integer>		 mIndexName = new ArrayList<Integer>();
	
	ComparatorVNumber mVNumComparator = new ComparatorVNumber();
	ComparatorName    mNameComparator = new ComparatorName();
	
	private class ComparatorVNumber implements Comparator<DevChannel> {

		@Override
		public int compare(DevChannel lhs, DevChannel rhs) {
			
			int ret = compareVNumber(lhs, rhs);
			if(ret == 0)
				return (lhs.mDevice.getID().compareTo(rhs.mDevice.getID()));
			return ret;
		}

		private int compareVNumber(DevChannel lhs, DevChannel rhs) {
			if (lhs.mChannel.mVirtualChannel_Major < rhs.mChannel.mVirtualChannel_Major)
				return -1;
			else if (lhs.mChannel.mVirtualChannel_Major > rhs.mChannel.mVirtualChannel_Major)
				return 1;
			else if (lhs.mChannel.mVirtualChannel_Minor < rhs.mChannel.mVirtualChannel_Minor)
				return -1;
			else if (lhs.mChannel.mVirtualChannel_Minor > rhs.mChannel.mVirtualChannel_Minor)
				return 1;
			return 0;
		}		
	}
	
	private class ComparatorName implements Comparator<DevChannel> {

		@Override
		public int compare(DevChannel lhs, DevChannel rhs) {
			
			int ret = compareName(lhs, rhs);
			if(ret == 0)
				return (lhs.mDevice.getID().compareTo(rhs.mDevice.getID()));
			return ret;
		}		
		
		public int compareName(DevChannel lhs, DevChannel rhs) {
			return lhs.mChannel.mName.compareToIgnoreCase(rhs.mChannel.mName);
		}
	}

	public DeviceMgr_ChannelList(List<TuningDevice> devs) {
		
		// loop through the devices and build a channel list
		Iterator<TuningDevice> iter = devs.iterator();
		while(iter.hasNext()) {
			TuningDevice dev = iter.next();
			ChannelList devList = dev.getChannelList();		
			if(devList == null) 
				continue;
			final int chanCount = devList.getChannelCount();
			for(int i = 0; i < chanCount; ++i) {
				DevChannel dcl = new DevChannel(dev, devList.getChannelAtIndex(i));
				mRawList.add(dcl);
				mSortedVNumber.add(dcl);
				mSortedName.add(dcl);
			}
		}		
		
		if(mRawList.size() == 0)
			return;
		
		Collections.sort(mSortedVNumber, mVNumComparator);
		mIndexVNumber.add(new Integer(0));
		DevChannel prev = mSortedVNumber.get(0);
		DevChannel next = null;
		for(int i = 1; i < mSortedVNumber.size(); ++i) {
			next = mSortedVNumber.get(i);
			if(0 != mVNumComparator.compareVNumber(prev, next))
				mIndexVNumber.add(new Integer(i));
			prev = next;
		}
		
		Collections.sort(mSortedName, mNameComparator);
		mIndexName.add(new Integer(0));
		prev = mSortedName.get(0);
		next = null;
		for(int i = 1; i < mSortedName.size(); ++i) {
			next = mSortedName.get(i);
			if(0 != mNameComparator.compareName(prev, next))
				mIndexName.add(new Integer(i));
			prev = next;
		}
	}
	
	private int comparePartialStringToChannelName(final String partial, String channelName) {
		
		if(channelName.length() > partial.length()) 
			channelName = channelName.substring(0, partial.length());
		return partial.compareToIgnoreCase(channelName);
	}
	
	private class IndexBounds {
		
		int startIndex = -1;
		int endIndex = -1;
		
		public boolean isValid() {
			return (startIndex > -1 && endIndex > -1);
		}
	}
	private IndexBounds findIndexBoundsForName(final String name) {

		IndexBounds ret = new IndexBounds();
		
		int startIndex = -1;
		int endIndex = -1;
		int begin = 0;
		int end = mIndexName.size();
		
		if(end == 0)
			return ret;
		
		
		while(begin <= end) {
			
			int currIndex = (begin + end) / 2;
			int index = mIndexName.get(currIndex);
			
			int cmp = comparePartialStringToChannelName(name, mSortedName.get(index).mChannel.mName);
			if(cmp == 0) {
				startIndex = currIndex;
				break;
			}
			else if (begin == end)
				break;
			else if(cmp < 0)
				end = currIndex;
			else
				begin = currIndex;
						
		}	
		
		if(startIndex != -1) {
			
			endIndex = startIndex + 1;
			while(startIndex > 0) {
				
				if(0 != comparePartialStringToChannelName(name, mSortedName.get(mIndexName.get(startIndex)).mChannel.mName)) {
					++startIndex;
					break;
				}
				--startIndex;
			}
			
			while(endIndex < mSortedName.size()) {
				
				if(0 != comparePartialStringToChannelName(name, mSortedName.get(mIndexName.get(endIndex)).mChannel.mName))
					break;
				++endIndex;
			}
			
			// now translate those index numbers back to proper indexes in the name array
			ret.startIndex = mIndexName.get(startIndex);
			ret.endIndex = mIndexName.get(endIndex);
		}
		
		return ret;
	}

	// this functions returns all the channels that start with the value of name
	// so "ab" returns "ab", "abc", "abd"
	// and each possiblitiy can be in there multiple times if different devices include them
	public List<Channel> getChannelsThatStartWithName(final String name) {
		
		List<Channel> ret = new ArrayList<Channel>();
		List<DevChannel> list = getDevChannelsThatStartWithName(name);
		Iterator<DevChannel> iter = list.iterator();
		DevChannel last = null;
		while(iter.hasNext()) {
			DevChannel curr = iter.next();
			
			if(last == null || last.equals(curr))
				ret.add(curr.mChannel);
			last = curr;
		}
		
		return ret;
	}
	
	public List<DevChannel> getDevChannelsThatStartWithName(final String name) {
		
		List<DevChannel> ret = new ArrayList<DevChannel>();
		IndexBounds bounds = findIndexBoundsForName(name);
		if(bounds.isValid()){
			
			ret = mSortedName.subList(bounds.startIndex, bounds.endIndex);
		}
		
		return ret;
	}
	
	
	private int comparePartialNumberToChannelNumber(int partialNumber, int channelNumber) {
		
		int lowerBound = partialNumber * 10;
		int upperBound = (partialNumber + 1) * 10;
		if(channelNumber < lowerBound)
			return -1;
		else if(channelNumber > upperBound)
			return 1;
		return 0;		
	}
	
	private IndexBounds findIndexBoundsForNumberX10(int number) {
		
		IndexBounds ret = new IndexBounds();
		
		int startIndex = -1;
		int endIndex = -1;
		int begin = 0;
		int end = mIndexVNumber.size();
		
		if(end == 0)
			return ret;
		
		
		while(begin <= end) {
			
			int currIndex = (begin + end) / 2;
			int index = mIndexVNumber.get(currIndex);
			
			int cmp = comparePartialNumberToChannelNumber(number, mSortedVNumber.get(index).mChannel.mVirtualChannel_Major);
			if(cmp == 0) {
				startIndex = currIndex;
				break;
			}
			else if (begin == end)
				break;
			else if(cmp < 0)
				end = currIndex;
			else
				begin = currIndex;
						
		}	
		
		if(startIndex != -1) {
			
			endIndex = startIndex + 1;
			while(startIndex > 0) {
				
				if(0 != comparePartialNumberToChannelNumber(number, mSortedVNumber.get(mIndexVNumber.get(startIndex)).mChannel.mVirtualChannel_Major)) {
					++startIndex;
					break;
				}
				--startIndex;
			}
			
			while(endIndex < mSortedName.size()) {
				
				if(0 != comparePartialNumberToChannelNumber(number, mSortedVNumber.get(mIndexVNumber.get(endIndex)).mChannel.mVirtualChannel_Major))
					break;
				++endIndex;
			}
			
			// now translate those index numbers back to proper indexes in the name array
			ret.startIndex = mIndexVNumber.get(startIndex);
			ret.endIndex = mIndexVNumber.get(endIndex);
		}
		
		return ret;
	}
	
	private int compareNumberToChannelNumber(int partialNumber, int channelNumber) {
		
		if(partialNumber < channelNumber)
			return -1;
		else if(partialNumber > channelNumber)
			return 1;
		return 0;		
	}
	
	private IndexBounds findIndexBoundsForNumber(int number) {
		
		IndexBounds ret = new IndexBounds();
		
		int startIndex = -1;
		int endIndex = -1;
		int begin = 0;
		int end = mIndexVNumber.size();
		
		if(end == 0)
			return ret;
		
		
		while(begin <= end) {
			
			int currIndex = (begin + end) / 2;
			int index = mIndexVNumber.get(currIndex);
			
			int cmp = compareNumberToChannelNumber(number, mSortedVNumber.get(index).mChannel.mVirtualChannel_Major);
			if(cmp == 0) {
				startIndex = currIndex;
				break;
			}
			else if (begin == end)
				break;
			else if(cmp < 0)
				end = currIndex;
			else if(begin == currIndex)
				break;
			else
				begin = currIndex;
						
		}	
		
		if(startIndex != -1) {
			
			endIndex = startIndex + 1;
			while(startIndex > 0) {
				
				if(0 != compareNumberToChannelNumber(number, mSortedVNumber.get(mIndexVNumber.get(startIndex)).mChannel.mVirtualChannel_Major)) {
					++startIndex;
					break;
				}
				--startIndex;
			}
			
			while(endIndex < mSortedName.size()) {
				
				if(0 != compareNumberToChannelNumber(number, mSortedVNumber.get(mIndexVNumber.get(endIndex)).mChannel.mVirtualChannel_Major))
					break;
				++endIndex;
			}
			
			// now translate those index numbers back to proper indexes in the name array
			ret.startIndex = mIndexVNumber.get(startIndex);
			ret.endIndex = mIndexVNumber.get(endIndex);
		}
		
		return ret;
	}
	
	public List<Channel> getChannelsThatStartWithNumber(int number) {
		
		List<DevChannel> list = getDevChannelsThatStartWithNumber(number);
		List<Channel> ret = new ArrayList<Channel>();
		DevChannel last = null;
		Iterator<DevChannel> iter = list.iterator();
		while(iter.hasNext()) {
			DevChannel curr = iter.next();
			
			if(last == null || last.equals(curr))
				ret.add(curr.mChannel);
			last = curr;
		}
		
		return ret;
	}
	
	public List<DevChannel> getDevChannelsThatStartWithNumber(int number) {
		
		List<DevChannel> ret = new ArrayList<DevChannel>();
		
		IndexBounds bounds = findIndexBoundsForNumber(number);
		if(bounds.isValid())
			ret = mSortedVNumber.subList(bounds.startIndex, bounds.endIndex);
		
		/*IndexBounds boundsX10 = findIndexBoundsForNumberX10(number);
		if(boundsX10.isValid()) {
			List<DevChannel> subList = mSortedVNumber.subList(boundsX10.startIndex, boundsX10.endIndex);
			Iterator<DevChannel> iter = subList.iterator();
			while(iter.hasNext())
				ret.add(iter.next());
		}*/
		
		return ret;
	}
	
	public List<DevChannel> getNextChannelNumberList(int number) {
		
		List<DevChannel> ret = new ArrayList<DevChannel>();
		
		IndexBounds bounds = findIndexBoundsForNumber(number+1);
		if(bounds.isValid())
			ret = mSortedVNumber.subList(bounds.startIndex, bounds.endIndex);
		
		return ret;
	}
	
	// I hate this
	public List<DevChannel> getFullListSortedByNumber() {
		return mSortedVNumber;
	}
	
	public List<DevChannel> getPreviousChannelNumberList(int number) {
		
		List<DevChannel> ret = new ArrayList<DevChannel>();
		
		if(number == 0)
			return ret;
		
		IndexBounds bounds = findIndexBoundsForNumber(number-1);
		if(bounds.isValid())
			ret = mSortedVNumber.subList(bounds.startIndex, bounds.endIndex);
		
		return ret;
		
	}
}
