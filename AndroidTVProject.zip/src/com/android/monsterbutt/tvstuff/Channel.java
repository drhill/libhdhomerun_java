package com.android.monsterbutt.tvstuff;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.silicondust.libhdhomerun.HDHomerun_Types.hdhomerun_channelscan_program_t;

public class Channel {

	private static int CURRENT_CHANNEL_VERSION = 1;
	public String mName = "";
	public int mVirtualChannel_Major = 0;
	public int mVirtualChannel_Minor = 0;
	public int mType = 0;
	public String mChannel = "";
	public String mChannelMap = "";
	public int mProgram = 0;
	
	public eAuthType mAuth = eAuthType.unSpecified;
	public eCCI   mCopyFlag = eCCI.unSpecified;
	
	public enum eAuthType {
		unSpecified,
		Subscribed,
		NotSubscribed
	};
	
	public enum eCCI {
		unSpecified,
		CopyFreely,
		CopyOnce,
		CopyNever
	}
	public Channel(DataInputStream in) throws IOException {
		
		switch(in.readInt()) {
			case 1:
				readVersion1(in);
				break;
			default:
				throw new IOException();
		}		
	}
	
	public Channel() {
	}

	public Channel(hdhomerun_channelscan_program_t program) {
		mVirtualChannel_Major = program.virtual_major;
		mVirtualChannel_Minor = program.virtual_minor;
		mType = program.type;
		mName = program.name;
		mProgram = program.program_number;
		
	}

	public boolean equals(Channel o) {
		
		if(mName.compareTo(o.mName) == 0)
			return true;
		return false;
	}
	private void readVersion1(DataInputStream in) throws IOException {
		
		
		mName = in.readUTF();
		mVirtualChannel_Major = in.readInt();
		mVirtualChannel_Minor = in.readInt();
		mProgram = in.readInt();
		mType = in.readInt();
		mChannel = in.readUTF();
		mChannelMap = in.readUTF();
		
		
		mAuth = eAuthType.valueOf(in.readUTF());
		mCopyFlag = eCCI.valueOf(in.readUTF());
	}
	
	public boolean isEmpty() {
		
		return (mName.length() == 0 && mVirtualChannel_Major == 0);
	}
	
	private void writeVersion(DataOutputStream out) throws IOException {
		
		out.writeInt(CURRENT_CHANNEL_VERSION);
	}
	
	public void writeToStream(DataOutputStream out) throws IOException {
		
		writeVersion(out);
		
		if(null != mName)
			out.writeUTF(mName);
		else
			out.writeUTF(null);
		
		out.writeInt(mVirtualChannel_Major);
		out.writeInt(mVirtualChannel_Minor);
		out.writeInt(mProgram);
		out.writeInt(mType);
		if(null != mChannel)
			out.writeUTF(mChannel);
		else
			out.writeUTF(null);
		if(null != mChannelMap)
			out.writeUTF(mChannelMap);
		else
			out.writeUTF(null);
		
		
		out.writeUTF(mAuth.toString());
		out.writeUTF(mCopyFlag.toString());
	}

}
